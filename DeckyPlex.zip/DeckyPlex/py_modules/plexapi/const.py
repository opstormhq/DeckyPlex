"""Constants used by plexapi."""

# Library version
MAJOR_VERSION = 4
MINOR_VERSION = 18
PATCH_VERSION = 3
__short_version__ = f"{MAJOR_VERSION}.{MINOR_VERSION}"
__version__ = f"{__short_version__}.{PATCH_VERSION}"
